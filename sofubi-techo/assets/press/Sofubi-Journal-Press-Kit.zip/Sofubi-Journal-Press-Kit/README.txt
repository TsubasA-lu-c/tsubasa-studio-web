Sofubi Journal — Press Kit

App Store:
https://apps.apple.com/us/app/sofubi-journal/id6795497288

Developer:
Tsubasa Studio
Independent iOS developer based in Japan

Media contact:
tsubasa.studio@icloud.com

Included assets:
- App icon (1024 x 1024 PNG)
- 8 official app screenshots

These assets may be used for editorial coverage of Sofubi Journal.
